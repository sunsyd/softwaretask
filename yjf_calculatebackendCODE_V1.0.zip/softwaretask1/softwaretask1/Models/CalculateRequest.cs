﻿namespace CalculatorBackend
{
    public class CalculateRequest
    {
        public string Expression { get; set; }
    }
}
