﻿namespace CalculatorBackend
{
    public class CalculateRequest
    {
        public string Id { get; set; }
        public string Expression { get; set; }
    }
}
